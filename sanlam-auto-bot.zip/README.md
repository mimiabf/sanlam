
# Sanlam Auto Bot

Ce script automatise la saisie du formulaire de tarification Sanlam à partir d'un fichier Excel.

## Étapes

1. Installer les dépendances :
   ```
   npm install
   ```

2. Lancer le script :
   ```
   node index.js
   ```

Le script remplit tous les champs et attend que vous cochiez le reCAPTCHA manuellement.
