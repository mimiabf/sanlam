
const { chromium } = require('playwright');
const XLSX = require('xlsx');

(async () => {
  const workbook = XLSX.readFile('Scenarios.xlsx');
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(sheet);

  const browser = await chromium.launch({ headless: false });
  const page = await browser.newPage();

  for (let i = 0; i < 1; i++) {
    const data = rows[i];
    console.log(`🔄 Simulation ${i + 1} :`, data);

    await page.goto('https://souscription-en-ligne.sanlam.ma/assurance-auto-simulation/tarification');

    await page.fill('#brand', 'Audi');
    await page.waitForSelector('li.MuiAutocomplete-option');
    await page.click('li.MuiAutocomplete-option');

    await page.click(`input[name="combustion"][value="D"]`);

    await page.click('#mui-component-select-horsePower');
    await page.waitForSelector('li[data-value="6"]');
    await page.click('li[data-value="6"]');

    await page.fill('input[name="circulationDate"]', '01/01/2022');
    await page.fill('input[name="newValue"]', '120000');
    await page.fill('input[name="marketValue"]', '100000');
    await page.fill('input[name="dateOfBirth"]', '01/01/1995');

    await page.fill('#city', 'Casablanca');
    await page.waitForSelector('li.MuiAutocomplete-option');
    await page.click('li.MuiAutocomplete-option');

    await page.fill('input[name="lastName"]', 'Test');
    await page.fill('input[name="firstName"]', 'Auto');
    await page.fill('input[type="tel"]', '0666666666');

    await page.click('input[name="drivingLicenceType"][value="0"]');
    await page.click('input[name="cgu"]');

    console.log('✅ Coche le reCAPTCHA manuellement puis clique sur Valider...');

    await page.waitForTimeout(120000); // 2 min

    await page.click('button[type="submit"]');
    await page.waitForLoadState('networkidle');

    await page.screenshot({ path: `sanlam_result_${i + 1}.png`, fullPage: true });
    console.log(`📸 Capture enregistrée pour le scénario ${i + 1}`);
  }

  await browser.close();
})();
